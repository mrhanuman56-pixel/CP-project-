AOS.init({
    duration: 680,
    once: true,
    offset: 55
});

/* NAVBAR SCROLL & ACTIVE LINK  */
window.addEventListener('scroll', function() {
    document.getElementById('nav').classList.toggle('scrolled', window.scrollY > 60);
    document.getElementById('btt').classList.toggle('show', window.scrollY > 300);
    document.querySelectorAll('section[id]').forEach(function(sec) {
        var top = sec.offsetTop - 110,
            bot = top + sec.offsetHeight;
        if (window.scrollY >= top && window.scrollY < bot) {
            document.querySelectorAll('.nav-link').forEach(function(l) {
                l.classList.remove('active');
            });
            var lnk = document.querySelector('.nav-link[href="#' + sec.id + '"]');
            if (lnk) lnk.classList.add('active');
        }
    });
});

/*  SMOOTH SCROLL + MOBILE NAV CLOSE  */
document.querySelectorAll('a[href^="#"]').forEach(function(a) {
    a.addEventListener('click', function(e) {
        var href = this.getAttribute('href');
        if (href === '#') return;
        var t = document.querySelector(href);
        if (t) {
            e.preventDefault();
            // Close Bootstrap mobile navbar if open
            var navCollapse = document.getElementById('navmenu');
            if (navCollapse && navCollapse.classList.contains('show')) {
                var bsCollapse = bootstrap.Collapse.getInstance(navCollapse);
                if (bsCollapse) {
                    bsCollapse.hide();
                } else {
                    navCollapse.classList.remove('show');
                }
            }
            // Scroll after slight delay to let navbar close
            setTimeout(function() {
                window.scrollTo({
                    top: t.offsetTop - 78,
                    behavior: 'smooth'
                });
            }, 50);
        }
    });
});


var searchOv = document.getElementById('searchOv');

document.getElementById('navSearchBtn').addEventListener('click', function() {
    searchOv.classList.add('open');
    document.body.style.overflow = 'hidden';
    setTimeout(function() {
        document.getElementById('searchInput').focus();
    }, 220);
});

document.getElementById('searchClose').addEventListener('click', closeSearch);

// Close when clicking backdrop
searchOv.addEventListener('click', function(e) {
    if (e.target === searchOv) closeSearch();
});

function closeSearch() {
    searchOv.classList.remove('open');
    document.body.style.overflow = '';
}

// Category buttons inside search box
document.querySelectorAll('.sovcat').forEach(function(btn) {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.sovcat').forEach(function(b) {
            b.classList.remove('active');
        });
        this.classList.add('active');
        var f = this.getAttribute('data-cat');
        closeSearch();
        setTimeout(function() {
            filterMenu(f);
            document.getElementById('menu').scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }, 300);
    });
});

// Trending tags fill the search input
document.querySelectorAll('.sovtrend .ttag').forEach(function(t) {
    t.addEventListener('click', function() {
        document.getElementById('searchInput').value = this.textContent.trim();
        document.getElementById('searchInput').focus();
    });
});


$(document).ready(function() {
	$('.magnific_popup').magnificPopup({
	  disableOn: 700,
	  type: 'iframe',
	  mainClass: 'mfp-fade',
	  removalDelay: 160,
	  preloader: false,
	  fixedContentPos: false,
	  disableOn: 300
	});	
});


function filterMenu(cat) {
    // sync filter buttons
    document.querySelectorAll('.filtbtn').forEach(function(b) {
        b.classList.toggle('active', b.getAttribute('data-f') === cat);
    });
    // sync category cards
    document.querySelectorAll('.catcard').forEach(function(c) {
        c.classList.toggle('active', c.getAttribute('data-filter') === cat);
    });
    // show/hide menu cards
    document.querySelectorAll('.mwrap').forEach(function(w) {
        var c = w.getAttribute('data-c');
        if (cat === 'all' || c === cat) {
            w.classList.remove('gone');
            w.style.opacity = '0';
            w.style.transform = 'translateY(16px)';
            setTimeout(function() {
                w.style.transition = 'opacity .38s,transform .38s';
                w.style.opacity = '1';
                w.style.transform = 'translateY(0)';
            }, 60);
        } else {
            w.classList.add('gone');
        }
    });
}

// Filter buttons
document.querySelectorAll('.filtbtn').forEach(function(btn) {
    btn.addEventListener('click', function() {
        filterMenu(this.getAttribute('data-f'));
    });
});

// Category section cards â†’ scroll + filter
document.querySelectorAll('.catcard').forEach(function(card) {
    card.addEventListener('click', function() {
        var f = this.getAttribute('data-filter');
        window.scrollTo({
            top: document.getElementById('menu').offsetTop - 80,
            behavior: 'smooth'
        });
        setTimeout(function() {
            filterMenu(f);
        }, 480);
    });
});


var menuPop = document.getElementById('menuPop');
var mpQty = 1;
var currentMenuCard = null;

function openMenuPop(card) {
    currentMenuCard = card;
    var img = card.getAttribute('data-img');
    var title = card.getAttribute('data-title');
    var cat = card.getAttribute('data-cat');
    var price = card.getAttribute('data-price');
    var old = card.getAttribute('data-old');
    var rating = parseFloat(card.getAttribute('data-rating'));
    var reviews = card.getAttribute('data-reviews');
    var cal = card.getAttribute('data-cal');
    var time = card.getAttribute('data-time');
    var desc = card.getAttribute('data-desc');
    var tags = card.getAttribute('data-tags') || '';

    document.getElementById('mpImg').setAttribute('src', img);
    document.getElementById('mpCat').textContent = cat;
    document.getElementById('mpTitle').textContent = title;

    var full = Math.round(rating),
        empty = 5 - full;
    document.getElementById('mpStars').innerHTML =
        '<i class="fas fa-star"></i>'.repeat(full) + 'â˜†'.repeat(empty) +
        ' <span style="color:#bbb;font-size:.78rem;">' + rating + ' (' + reviews + ' reviews)</span>';

    document.getElementById('mpDesc').textContent = desc;

    document.getElementById('mpPrice').innerHTML =
        price + (old ? '<small style="color:#ccc;text-decoration:line-through;margin-left:8px;font-size:1rem;">' + old + '</small>' : '');

    document.getElementById('mpMeta').innerHTML =
        (cal ? '<div class="mpm"><div class="mpmv">' + cal + ' kcal</div><div class="mpml">Calories</div></div>' : '') +
        (time ? '<div class="mpm"><div class="mpmv">' + time + ' min</div><div class="mpml">Prep Time</div></div>' : '') +
        (Number.isFinite(rating) ? '<div class="mpm"><div class="mpmv">' + rating + '/5</div><div class="mpml">Rating</div></div>' : '');

    document.getElementById('mpTags').innerHTML =
        tags.split(',').filter(Boolean).map(function(t) {
            return '<span class="mptag">' + t.trim() + '</span>';
        }).join('');

    mpQty = 1;
    document.getElementById('mpQnum').textContent = 1;
    document.getElementById('mpAddCart').innerHTML = '<i class="fas fa-shopping-cart"></i> Add to Cart';
    document.getElementById('mpAddCart').style.background = '';

    menuPop.classList.add('open');
    lockBodyScroll();
}

// Card click open popup
document.querySelectorAll('.mcard').forEach(function(card) {
    card.addEventListener('click', function() {
        openMenuPop(this);
    });
});

// + button  open popup (stop propagation to avoid double firing)
document.querySelectorAll('.madd').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
        e.stopPropagation();
        openMenuPop(this.closest('.mcard'));
    });
});

// Heart toggle (no popup)
document.querySelectorAll('.mhrt').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
        e.stopPropagation();
        var ico = this.querySelector('i');
        ico.classList.toggle('far');
        ico.classList.toggle('fas');
        this.style.color = ico.classList.contains('fas') ? 'var(--primary)' : '#ccc';
    });
});

// Close popup
document.getElementById('mpClose').addEventListener('click', closeMenuPop);
menuPop.addEventListener('click', function(e) {
    if (e.target === this) closeMenuPop();
});

function closeMenuPop() {
    menuPop.classList.remove('open');
    // keep lock if cart is open
    if (!document.getElementById('cartPanel') || !document.getElementById('cartPanel').classList.contains('open')) {
        unlockBodyScroll();
    }
}

// Qty +/-
document.getElementById('mpPlus').addEventListener('click', function() {
    document.getElementById('mpQnum').textContent = ++mpQty;
});
document.getElementById('mpMinus').addEventListener('click', function() {
    if (mpQty > 1) document.getElementById('mpQnum').textContent = --mpQty;
});

// ========== CART SYSTEM ==========
var cart = []; // { id, title, price, img, qty }
var DELIVERY_FEE = 30;
var WHATSAPP_NUMBER = '919405916976'; // +91 94059 16976
var _scrollLockY = 0;

// C code compiled to wasm for subtotal calculation
var wasmCalc = null;
var wasmReady = false;

(function() {
    fetch('js/cart_calc.wasm')
        .then(function(r) { return r.arrayBuffer(); })
        .then(function(bytes) { return WebAssembly.instantiate(bytes); })
        .then(function(result) {
            wasmCalc = result.instance.exports;
            wasmReady = true;
        })
        .catch(function() {
            wasmReady = false;
        });
})();

function lockBodyScroll() {
    _scrollLockY = window.scrollY || window.pageYOffset || 0;
    document.body.style.position = 'fixed';
    document.body.style.top = '-' + _scrollLockY + 'px';
    document.body.style.left = '0';
    document.body.style.right = '0';
    document.body.style.width = '100%';
    document.body.style.overflow = 'hidden';
}
function unlockBodyScroll() {
    document.body.style.position = '';
    document.body.style.top = '';
    document.body.style.left = '';
    document.body.style.right = '';
    document.body.style.width = '';
    document.body.style.overflow = '';
    window.scrollTo(0, _scrollLockY || 0);
}


function parsePrice(str) {
    if (!str) return 0;
    var n = parseInt(String(str).replace(/[^0-9]/g, ''), 10);
    return isNaN(n) ? 0 : n;
}

function cartItemId(title) {
    return String(title).toLowerCase().replace(/\s+/g, '-');
}

function getCartCount() {
    return cart.reduce(function(s, i) { return s + i.qty; }, 0);
}

function getCartSubtotal() {
    function jsFallback() {
        return cart.reduce(function(s, i) { return s + i.price * i.qty; }, 0);
    }

    if (!wasmReady || !wasmCalc || cart.length === 0) {
        return jsFallback();
    }

    try {
        var n = cart.length;
        var pricesPtr = 0;
        var qtysPtr = n * 4;
        var mem = new Int32Array(wasmCalc.memory.buffer);

        for (var i = 0; i < n; i++) {
            mem[(pricesPtr >> 2) + i] = cart[i].price | 0;
            mem[(qtysPtr >> 2) + i] = cart[i].qty | 0;
        }

        return wasmCalc.calculate_subtotal(pricesPtr, qtysPtr, n) | 0;
    } catch (e) {
        return jsFallback();
    }
}

function updateCartBadge() {
    var cnt = getCartCount();
    var el = document.getElementById('cartCount');
    if (el) el.textContent = cnt;
    var floatBtn = document.getElementById('cartFloat');
    if (floatBtn) {
        if (cnt > 0) floatBtn.classList.add('has-items');
        else floatBtn.classList.remove('has-items');
    }
}

function renderCart() {
    var container = document.getElementById('cartItems');
    var empty = document.getElementById('cartEmpty');
    var footer = document.getElementById('cartFooter');
    if (!container) return;

    // remove existing item nodes (keep empty placeholder)
    Array.from(container.querySelectorAll('.cart-item')).forEach(function(n) { n.remove(); });

    if (cart.length === 0) {
        if (empty) empty.style.display = '';
        if (footer) footer.style.display = 'none';
        updateCartBadge();
        return;
    }

    if (empty) empty.style.display = 'none';
    if (footer) footer.style.display = '';

    cart.forEach(function(item) {
        var row = document.createElement('div');
        row.className = 'cart-item';
        row.setAttribute('data-id', item.id);
        row.innerHTML =
            '<img class="cart-item-img" src="' + (item.img || '') + '" alt="">' +
            '<div class="cart-item-body">' +
            '  <div class="cart-item-title">' + item.title + '</div>' +
            '  <div class="cart-item-price">₹' + item.price + '</div>' +
            '  <div class="cart-item-actions">' +
            '    <button type="button" class="cart-qty-btn cart-minus" data-id="' + item.id + '">−</button>' +
            '    <span class="cart-qty-val">' + item.qty + '</span>' +
            '    <button type="button" class="cart-qty-btn cart-plus" data-id="' + item.id + '">+</button>' +
            '    <button type="button" class="cart-item-remove" data-id="' + item.id + '" title="Remove"><i class="fas fa-trash-alt"></i></button>' +
            '  </div>' +
            '  <div class="cart-item-line">₹' + (item.price * item.qty) + '</div>' +
            '</div>';
        container.appendChild(row);
    });

    var sub = getCartSubtotal();
    var total = sub + DELIVERY_FEE;
    var subEl = document.getElementById('cartSubtotal');
    var totEl = document.getElementById('cartTotal');
    var delEl = document.getElementById('cartDelivery');
    if (subEl) subEl.textContent = '₹' + sub;
    if (delEl) delEl.textContent = '₹' + DELIVERY_FEE;
    if (totEl) totEl.textContent = '₹' + total;
    updateCartBadge();
}

function addToCart(title, priceStr, img, qty) {
    var id = cartItemId(title);
    var price = parsePrice(priceStr);
    var existing = cart.find(function(i) { return i.id === id; });
    if (existing) {
        existing.qty += qty;
    } else {
        cart.push({ id: id, title: title, price: price, img: img || '', qty: qty });
    }
    renderCart();
}

function setCartQty(id, delta) {
    var item = cart.find(function(i) { return i.id === id; });
    if (!item) return;
    item.qty += delta;
    if (item.qty <= 0) {
        cart = cart.filter(function(i) { return i.id !== id; });
    }
    renderCart();
}

function removeFromCart(id) {
    cart = cart.filter(function(i) { return i.id !== id; });
    renderCart();
}

function openCart() {
    document.getElementById('cartPanel').classList.add('open');
    document.getElementById('cartOverlay').classList.add('open');
    document.getElementById('cartPanel').setAttribute('aria-hidden', 'false');
    lockBodyScroll();
    renderCart();
}

function closeCart() {
    document.getElementById('cartPanel').classList.remove('open');
    document.getElementById('cartOverlay').classList.remove('open');
    document.getElementById('cartPanel').setAttribute('aria-hidden', 'true');
    if (!document.getElementById('menuPop').classList.contains('open')) {
        unlockBodyScroll();
    }
}

function buildWhatsAppMessage() {
    var name = (document.getElementById('orderName').value || '').trim();
    var phone = (document.getElementById('orderPhone').value || '').trim();
    var address = (document.getElementById('orderAddress').value || '').trim();
    var lines = [];
    lines.push('*New Order from INSTANTS*');
    lines.push('');
    lines.push('*Customer*');
    lines.push('Name: ' + name);
    lines.push('Phone: ' + phone);
    lines.push('Address: ' + address);
    lines.push('');
    lines.push('*Items*');
    cart.forEach(function(item) {
        lines.push('• ' + item.title + ' x' + item.qty + ' — ₹' + (item.price * item.qty));
    });
    lines.push('');
    var sub = getCartSubtotal();
    lines.push('Subtotal: ₹' + sub);
    lines.push('Delivery: ₹' + DELIVERY_FEE);
    lines.push('*Total: ₹' + (sub + DELIVERY_FEE) + '*');
    return lines.join('\n');
}

function placeOrderOnWhatsApp() {
    var name = (document.getElementById('orderName').value || '').trim();
    var phone = (document.getElementById('orderPhone').value || '').trim();
    var address = (document.getElementById('orderAddress').value || '').trim();
    if (!name) {
        alert('Please enter your name.');
        document.getElementById('orderName').focus();
        return;
    }
    if (!/^[0-9]{10}$/.test(phone)) {
        alert('Please enter a valid 10-digit phone / WhatsApp number.');
        document.getElementById('orderPhone').focus();
        return;
    }
    if (!address) {
        alert('Please enter your delivery address.');
        document.getElementById('orderAddress').focus();
        return;
    }
    if (cart.length === 0) {
        alert('Your cart is empty.');
        return;
    }
    var msg = buildWhatsAppMessage();
    var url = 'https://wa.me/' + WHATSAPP_NUMBER + '?text=' + encodeURIComponent(msg);
    window.open(url, '_blank', 'noopener');
}

// Wire cart UI
(function initCartUI() {
    var floatBtn = document.getElementById('cartFloat');
    var closeBtn = document.getElementById('cartClose');
    var overlay = document.getElementById('cartOverlay');
    var orderBtn = document.getElementById('orderWhatsApp');
    var itemsEl = document.getElementById('cartItems');

    if (floatBtn) floatBtn.addEventListener('click', openCart);
    if (closeBtn) closeBtn.addEventListener('click', closeCart);
    if (overlay) overlay.addEventListener('click', closeCart);
    if (orderBtn) orderBtn.addEventListener('click', placeOrderOnWhatsApp);

    if (itemsEl) {
        itemsEl.addEventListener('click', function(e) {
            var btn = e.target.closest('[data-id]');
            if (!btn) return;
            var id = btn.getAttribute('data-id');
            if (btn.classList.contains('cart-plus')) setCartQty(id, 1);
            else if (btn.classList.contains('cart-minus')) setCartQty(id, -1);
            else if (btn.classList.contains('cart-item-remove') || btn.closest('.cart-item-remove')) removeFromCart(id);
        });
    }
    updateCartBadge();
})();

// Add to cart button
document.getElementById('mpAddCart').addEventListener('click', function() {
    if (!currentMenuCard) return;
    var title = currentMenuCard.getAttribute('data-title') || '';
    var price = currentMenuCard.getAttribute('data-price') || '0';
    var img = currentMenuCard.getAttribute('data-img') || '';
    addToCart(title, price, img, mpQty);
    this.innerHTML = '<i class="fas fa-check"></i> Added to Cart!';
    this.style.background = 'linear-gradient(135deg,var(--green),#1a4a35)';
    var self = this;
    setTimeout(function() {
        // Close menu without unlocking; openCart will keep lock
        menuPop.classList.remove('open');
        self.innerHTML = '<i class="fas fa-shopping-cart"></i> Add to Cart';
        self.style.background = '';
        openCart();
    }, 700);
});


var resBtn = document.getElementById('resBtn');
if (resBtn) resBtn.addEventListener('click', function() {
    var btn = this;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Booking...';
    btn.disabled = true;
    setTimeout(function() {
        btn.innerHTML = '<i class="fas fa-calendar-check"></i> Confirm Reservation';
        btn.disabled = false;
        var ok = document.getElementById('resOk');
        ok.style.display = 'block';
        ok.scrollIntoView({
            behavior: 'smooth',
            block: 'nearest'
        });
    }, 1500);
});


var ctcBtn = document.getElementById('ctcBtn');
if (ctcBtn) ctcBtn.addEventListener('click', function() {
    var btn = this;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
    btn.disabled = true;
    setTimeout(function() {
        btn.innerHTML = '<i class="fas fa-paper-plane"></i> Send Message';
        btn.disabled = false;
        var ok = document.getElementById('ctcOk');
        ok.style.display = 'block';
        ok.scrollIntoView({
            behavior: 'smooth',
            block: 'nearest'
        });
    }, 1500);
});


var galPop = document.getElementById('galPop');
var galData = [];
var galIdx = 0;

document.querySelectorAll('.gitem').forEach(function(item) {
    galData.push({
        img: item.getAttribute('data-gimg'),
        title: item.getAttribute('data-gtitle'),
        desc: item.getAttribute('data-gdesc')
    });
    item.addEventListener('click', function() {
        openGal(parseInt(this.getAttribute('data-gi')));
    });
});

function openGal(i) {
    galIdx = i;
    var g = galData[i];
    document.getElementById('gpImg').setAttribute('src', g.img);
    document.getElementById('gpTitle').textContent = g.title;
    document.getElementById('gpDesc').innerHTML = g.desc;
    galPop.classList.add('open');
    document.body.style.overflow = 'hidden';
}

document.getElementById('gpClose').addEventListener('click', closeGal);
galPop.addEventListener('click', function(e) {
    if (e.target === this) closeGal();
});

function closeGal() {
    galPop.classList.remove('open');
    document.body.style.overflow = '';
}

document.getElementById('gpPrev').addEventListener('click', function() {
    openGal((galIdx - 1 + galData.length) % galData.length);
});
document.getElementById('gpNext').addEventListener('click', function() {
    openGal((galIdx + 1) % galData.length);
});

/*  ESC key closes everything */
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeSearch();
        closeMenuPop();
        closeGal();
        if (typeof $.magnificPopup !== 'undefined') $.magnificPopup.close();
    }
});


if (document.querySelector('.tesSwiper')) {
    new Swiper('.tesSwiper', {
        slidesPerView: 1,
        spaceBetween: 22,
        loop: true,
        autoplay: { delay: 4000, disableOnInteraction: false },
        pagination: { el: '.swiper-pagination', clickable: true },
        breakpoints: { 640: { slidesPerView: 2 }, 1024: { slidesPerView: 3 } }
    });
}


var cH = 8,
    cM = 45,
    cS = 30;
setInterval(function() {
    cS--;
    if (cS < 0) {
        cS = 59;
        cM--;
    }
    if (cM < 0) {
        cM = 59;
        cH--;
    }
    if (cH < 0) {
        cH = 8;
        cM = 45;
        cS = 30;
    }
    var cdH = document.getElementById('cdH');
    var cdM = document.getElementById('cdM');
    var cdS = document.getElementById('cdS');
    if (cdH && cdM && cdS) {
        cdH.textContent = String(cH).padStart(2, '0');
        cdM.textContent = String(cM).padStart(2, '0');
        cdS.textContent = String(cS).padStart(2, '0');
    }
}, 1000);

/* â”€â”€ NEWSLETTER â”€â”€ */
document.getElementById('nlBtn').addEventListener('click', function() {
    var email = document.getElementById('nlEmail').value;
    if (email && email.includes('@')) {
        var btn = this;
        btn.textContent = 'âœ“ Subscribed!';
        btn.style.background = '#4ade80';
        btn.style.color = '#222';
        document.getElementById('nlEmail').value = '';
        setTimeout(function() {
            btn.textContent = 'Subscribe';
            btn.style.background = '';
            btn.style.color = '';
        }, 3000);
    }
});

/*  NUMBER COUNTER ANIMATION*/
var numAnimated = false;
window.addEventListener('scroll', function() {
    var hero = document.getElementById('hero');
    if (!numAnimated && hero && window.scrollY > hero.offsetHeight - 300) {
        numAnimated = true;
        document.querySelectorAll('.snum').forEach(function(el) {
            var txt = el.textContent;
            var num = parseInt(txt);
            var suf = txt.replace(/[0-9]/g, '');
            if (isNaN(num)) return;
            var start = 0;
            var step = Math.ceil(num / 55);
            var iv = setInterval(function() {
                start += step;
                if (start >= num) {
                    start = num;
                    clearInterval(iv);
                }
                el.textContent = start + suf;
            }, 1400 / 55);
        });
    }
});

/* PHONE FIELDS: allow only digits, max 10 */
document.querySelectorAll('.phone-only').forEach(function(input) {
    // remove anything that is not a digit while typing or pasting
    input.addEventListener('input', function() {
        this.value = this.value.replace(/[^0-9]/g, '').slice(0, 10);
    });
});
